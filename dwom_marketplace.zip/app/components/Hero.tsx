import styles from './Hero.module.css';

export default function Hero() {
    return (
        <section className={styles.hero}>
            <div className={`container ${styles.content}`}>
                <h1 className={styles.title}>
                    <span>Unleash your</span>
                    <br />
                    <span className="text-gradient">African potential</span>
                </h1>
                <p className={styles.subtitle}>
                    The premier marketplace for digital products, trading signals, and communities across Ghana, Nigeria, and beyond.
                </p>
                <div className={styles.actions}>
                    <button className="btn btn-primary">Explore Marketplace</button>
                    <button className="btn btn-secondary">Start Selling</button>
                </div>
            </div>
        </section>
    );
}
