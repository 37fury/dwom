import Navbar from '../../components/Navbar';
import Footer from '../../components/Footer';
import styles from './product.module.css';
import PurchaseButton from '../../components/PurchaseButton';

// Mock DB fetcher
const getProduct = (id: string) => {
    return {
        id,
        title: 'Accra Forex Kings VIP',
        category: 'Forex & Crypto',
        price: 500,
        currency: 'GH₵',
        interval: 'month',
        description: `
      <h2>Master the Markets with Ghana's Top Traders</h2>
      <p>Join over 5,000 students learning to trade Forex, Crypto, and Indices. Our VIP signal room provides daily setups with 85% accuracy.</p>
      <ul>
        <li>✅ Daily Gold (XAUUSD) Signals</li>
        <li>✅ Live Zoom Sessions</li>
        <li>✅ Beginner to Pro Course</li>
        <li>✅ 24/7 Mentorship Support</li>
      </ul>
      <p>Stop gambling and start trading. Join the Kings today.</p>
    `,
        rating: 4.9,
        reviews: 1240,
        features: ['Instant Access', 'Mobile App', 'Community Chat'],
    };
};

export default async function ProductPage({ params }: { params: Promise<{ id: string }> }) {
    const { id } = await params;
    const product = getProduct(id);

    return (
        <main className={styles.wrapper}>
            <Navbar />

            <div className={`container ${styles.layout}`}>
                {/* Left Column: Media & Details */}
                <div className={styles.mainContent}>
                    <div className={styles.gallery}>
                        <div className={styles.mainImage}>
                            <span>Cover Image</span>
                        </div>
                        <div className={styles.thumbnails}>
                            <div className={styles.thumb} />
                            <div className={styles.thumb} />
                            <div className={styles.thumb} />
                        </div>
                    </div>

                    <div className={styles.description}>
                        <div dangerouslySetInnerHTML={{ __html: product.description }} />
                    </div>
                </div>

                {/* Right Column: Purchase Card */}
                <div className={styles.sidebar}>
                    <div className={styles.purchaseCard}>
                        <h1 className={styles.title}>{product.title}</h1>
                        <div className={styles.priceRow}>
                            <span className={styles.price}>{product.currency}{product.price}</span>
                            <span className={styles.interval}>/{product.interval}</span>
                        </div>

                        <div className={styles.rating}>
                            ⭐⭐⭐⭐⭐ <span>{product.rating} ({product.reviews} reviews)</span>
                        </div>

                        <PurchaseButton
                            className={styles.btnBuy}
                            productTitle={product.title}
                            price={product.price}
                            currency={product.currency}
                        >
                            Unlock Access
                        </PurchaseButton>

                        <div className={styles.guarantee}>
                            Authorized by dwom • Cancel anytime
                        </div>

                        <hr className={styles.divider} />

                        <ul className={styles.featuresList}>
                            {product.features.map(f => (
                                <li key={f}>✓ {f}</li>
                            ))}
                        </ul>
                    </div>
                </div>
            </div>

            <Footer />
        </main>
    );
}
