import styles from './page.module.css';

export default function DashboardPage() {
    return (
        <div className={styles.container}>
            {/* Wallet Summary */}
            <section className={styles.section}>
                <h2 className={styles.heading}>Wallet</h2>
                <div className={styles.walletCard}>
                    <div className={styles.balanceInfo}>
                        <span className={styles.label}>Total Balance</span>
                        <span className={styles.balance}>GH₵ 1,250.00</span>
                    </div>
                    <div className={styles.actions}>
                        <button className={styles.btnWithdraw}>Withdraw</button>
                        <button className={styles.btnTopUp}>Top Up</button>
                    </div>
                </div>
            </section>

            {/* Active Memberships */}
            <section className={styles.section}>
                <h2 className={styles.heading}>Active Memberships</h2>
                <div className={styles.grid}>
                    {/* Mock Sub 1 */}
                    <div className={styles.subCard}>
                        <div className={styles.subHeader}>
                            <div className={styles.subIcon} style={{ background: '#ff4f12' }}>FK</div>
                            <div>
                                <h3 className={styles.subTitle}>Accra Forex Kings</h3>
                                <span className={styles.subStatus}>Active • Renews Oct 24</span>
                            </div>
                        </div>
                        <button className={styles.btnAccess}>Launch App</button>
                    </div>

                    {/* Mock Sub 2 */}
                    <div className={styles.subCard}>
                        <div className={styles.subIcon} style={{ background: '#10b981' }}>TM</div>
                        <div>
                            <h3 className={styles.subTitle}>Tech Mentors GH</h3>
                            <span className={styles.subStatus}>Active • Renews Nov 01</span>
                        </div>
                        <button className={styles.btnAccess}>Launch App</button>
                    </div>
                </div>
            </section>
        </div>
    );
}
